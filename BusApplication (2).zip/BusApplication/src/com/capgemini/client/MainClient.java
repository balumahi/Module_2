package com.capgemini.client;



import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.*;

public class MainClient {

private BusService busService;

public MainClient() {

busService = new BusServiceImpl();

}

public static void main(String[] args) {

MainClient btbaUI=new MainClient();

while(true)

{

btbaUI.showMenu();

System.out.println();

}

}

private void showMenu() {

Scanner sc=new Scanner(System.in);

System.out.println("**********Bus Ticket Booking Application**********");

System.out.println("1. Book Ticket");

System.out.println("2. Exit");

System.out.println("Enter your Choice:");

int choice=sc.nextInt();

switch(choice)

{

case 1:

bookTicket();

break;

case 2:

System.out.println("Thank You! Exiting Application");

System.exit(0);

break;

default:

System.out.println("Invalid input");

break;

}

}

private void bookTicket() {

try{

List<BusBean> busBean=busService.retrieveBusDetails();

Iterator<BusBean> it=busBean.iterator();

System.out.println("busId \t busType \t FromStop \t ToStop \t Available Seats \t Fare \t Date Of Journey");

while(it.hasNext())

{

BusBean bus=it.next();

System.out.println(bus.getBusId()+" \t "+bus.getBusType()+" \t "+bus.getFromStop()+" \t "+bus.getToStop()+" \t\t "+bus.getAvailableSeats()+" \t\t "+bus.getFare()+" \t "+bus.getDateOfJourney());

}

}

catch(BookingException e)

{

e.printStackTrace();

}

catch(Exception e)

{

e.printStackTrace();

}

Scanner sc=new Scanner(System.in);

BookingBean bookingBean=new BookingBean();

System.out.println("Provide Booking Information");

System.out.println("Enter Customer Id:");

String custId=sc.next();

Pattern p=Pattern.compile("^[A-Z][0-9]{5}$");

Matcher m=p.matcher(custId);

if(!m.find())

{	System.out.println("Invalid Customer ID");

//throw new BookingException("Invalid Customer ID");

}

else

{

bookingBean.setCustId(custId);

System.out.println("Enter Bus Id:");

int busId=sc.nextInt();

System.out.println("Enter number of Seats:");

int noOfSeats=sc.nextInt();

if(noOfSeats>0){

bookingBean.setBusId(busId);

bookingBean.setCustId(custId);

bookingBean.setNoOfSeat(noOfSeats);

}

else

{

System.out.println("Number Of Seats should be greater than 0");

throw new BookingException("Number Of Seats should be greater than 0");

}

try{

int id=busService.bookTicket(bookingBean);

System.out.println("Thank you. Your Booking Id is "+id);

}

catch(BookingException e)

{

e.printStackTrace();

}

catch(Exception e)

{

e.printStackTrace();

}

}

}

}