package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.util.DBUtil;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;

public class BusDaoImpl implements BusDao{

//Logger

static Logger myLogger;

public BusDaoImpl()

{

PropertyConfigurator.configure("log4j.properties");

myLogger=Logger.getLogger(BusDaoImpl.class.getName());

}

/************************************************************************************

* Method Name: retrieveBusDetails()

* Return Type: ArrayList

* Author Name:

* Creation Date : 01-03-2017

* Description: To retrieve All Bus Details

************************************************************************************/

@Override

public ArrayList<BusBean> retrieveBusDetails() {

ArrayList<BusBean> bus=new ArrayList<BusBean>();

try(Connection con=DBUtil.getConnection())

{

Statement stm=con.createStatement();

ResultSet rs=stm.executeQuery("select * from BusDetails");

while(rs.next())

{

BusBean busBean=new BusBean();

busBean.setBusId(rs.getInt("busId"));

busBean.setBusType(rs.getString("busType"));

busBean.setFromStop(rs.getString("fromStop"));

busBean.setToStop(rs.getString("toStop"));

busBean.setFare(rs.getInt("fare"));

busBean.setAvailableSeats(rs.getInt("availableSeats"));

busBean.setDateOfJourney(rs.getDate("dateOfJourney"));

bus.add(busBean);

}

}

catch (SQLException e) {

//	e.printStackTrace();

throw new BookingException(e.getMessage());

}

catch (Exception e) {

//e.printStackTrace();

throw new BookingException(e.getMessage());

}

return bus;

}

/************************************************************************************

* Method Name: bookTicket()

* Input Parameters: BookingBean Object

* Return Type: int

* Author Name:

* Creation Date : 01-03-2017

* Description: To book bus ticket for a customer

************************************************************************************/

@Override

public int bookTicket(BookingBean bookingBean) throws BookingException {

int generatedId=-1;

try(Connection con=DBUtil.getConnection())

{

Statement stm=con.createStatement();

ResultSet rs=stm.executeQuery("select Booking_Id_Seq.nextVal from dual");

if(rs.next()==false)

throw new BookingException("Something went wrong while generating booking id");

int id=rs.getInt(1);

String customerId=bookingBean.getCustId();

int busId=bookingBean.getBusId();

int noOfSeats=bookingBean.getNoOfSeat();

PreparedStatement pstm1=con.prepareStatement("select availableSeats from BusDetails where busId=?");

pstm1.setInt(1,busId);

ResultSet rs1=pstm1.executeQuery();

if(rs1.next()==false)

throw new BookingException("Invalid Bus Id");

int availableSeats=rs1.getInt(1);

if(availableSeats>=noOfSeats)

{

PreparedStatement pstm2=con.prepareStatement("insert into BookingDetails values(?,?,?,?)");

pstm2.setInt(1,id);

pstm2.setString(2,customerId);

pstm2.setInt(3,busId);

pstm2.setInt(4, noOfSeats);

pstm2.execute();

generatedId=id;

int updatedAvailableSeats=availableSeats-noOfSeats;

PreparedStatement pstm3=con.prepareStatement("update BusDetails set availableSeats=? where busId=?");

pstm3.setInt(1,updatedAvailableSeats);

pstm3.setInt(2,busId);

pstm3.execute();

myLogger.info("Ticket Booked Sucessfully ");

}

else

{

System.out.println("Sorry No Seats Available");

//throw new BookingException("No Seats Avaialble");

}

}

catch (SQLException ex) {

//e1.printStackTrace();

myLogger.error(ex.getMessage());

throw new BookingException(ex.getMessage());

}

catch(Exception ex)

{

//ex.printStackTrace();

throw new BookingException(ex.getMessage());

}

return generatedId;

}

}


/*public class BookingException extends RuntimeException{

public BookingException() {

super();

// TODO Auto-generated constructor stub

}

public BookingException(String arg0, Throwable arg1, boolean arg2,

boolean arg3) {

super(arg0, arg1, arg2, arg3);

// TODO Auto-generated constructor stub

}

public BookingException(String arg0, Throwable arg1) {

super(arg0, arg1);

// TODO Auto-generated constructor stub

}

public BookingException(String arg0) {

super(arg0);

// TODO Auto-generated constructor stub

}

public BookingException(Throwable arg0) {

super(arg0);

// TODO Auto-generated constructor stub

}

}*/