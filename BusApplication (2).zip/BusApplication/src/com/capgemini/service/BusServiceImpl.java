package com.capgemini.service;



import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.*;
import com.capgemini.exception.BookingException;

public class BusServiceImpl implements BusService{

private BusDao busDao;

public BusServiceImpl()

{

busDao=new BusDaoImpl();

}

@Override

public ArrayList<BusBean> retrieveBusDetails() {

return busDao.retrieveBusDetails();

}

@Override

public int bookTicket(BookingBean bookingBean) throws BookingException {

return busDao.bookTicket(bookingBean);

}

}