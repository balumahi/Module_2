
  
  create table customer(id number,name varchar2(30),department varchar2(20),designation varchar2(30),salary number(10,2),primary key(id));
  
  select * from Employee;
  
  
  
  create sequence empIdseq start with 1000;
  
  select empIdseq.nextVal from dual;
  
  