package com.capgemini.core.ems.service;

import java.util.List;
import com.capgemini.core.ems.exceptions.*;
import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.dao.EmployeeDAOImpl;
import com.capgemini.core.ems.dao.IEmployeeDAO;
import com.capgemini.core.ems.exceptions.EmployeeException;
import com.capgemini.core.ems.bean.*;

public class EmployeeServiceImpl implements IEmployeeService {

	
	// Loose coupling
	private IEmployeeDAO employeeDAO;
	
	public EmployeeServiceImpl()
	{
		employeeDAO = new EmployeeDAOImpl();
	}
		
	@Override
	public int addEmployee(Employee e) throws EmployeeException 
	{
		return employeeDAO.addEmployee(e);

	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {

		return employeeDAO.getEmployee(id);
	}

	
	@Override
	public Employee removeEmployee(int id) throws EmployeeException {
		
		return employeeDAO.removeEmployee(id);

	}

	@Override
	public List<Employee> getEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployee();
	}

	@Override
	public void updateEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		
	}

}
