package com.capgemini.core.ems.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class DBUtil 
{

	private static Properties loadProperties(String fileName)
	{
		InputStream propsFile = null;
		
		Properties propertyFile = new Properties();
		
		try
		{
			propsFile = new FileInputStream(fileName);
			propertyFile.load(propsFile);
			propsFile.close();
		}
		catch (Exception e)
		{
			System.out.println("I/O Exception");
			e.printStackTrace();
			
			
			//can't connect to database so terminating application
			System.exit(1);
		}
		return propertyFile;
	}
	

	public static Connection getConnection() throws SQLException
	{
		
		
		final String PROFILE = "MyApplication.properties";
		
		Properties dbProperties;
		dbProperties = loadProperties(PROFILE);
		
		OracleDataSource ods = new OracleDataSource();
		
		
		// Set the user name, password, driver type and network protocol
		
		ods.setUser(dbProperties.getProperty("username"));
		ods.setPassword(dbProperties.getProperty("password"));
		ods.setDriverType(dbProperties.getProperty("drivertype"));
		ods.setNetworkProtocol(dbProperties.getProperty("networkprotocol"));
		ods.setURL(dbProperties.getProperty("url"));
		
		
		return ods.getConnection();
		
		
		/*OracleDataSource ods= null;
		
		
			ods = new OracleDataSource();
			ods.setUser("Labg103trg27");
			ods.setPassword("labg103oracle");
			ods.setDriverType("thin");
			ods.setNetworkProtocol("tcp");
			ods.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");
		
		
		return ods.getConnection();*/
	
	}
}
	
