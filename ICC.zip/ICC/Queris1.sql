 
  
create table players(Playerid number, Name varchar2(10), Country varchar2(20), DOB date, Battingstyle varchar2(10),
Noofcentures number, Noofmatchesplayed number, Totalruns number, primary key(Playerid));


select * from players;
create sequence playerIdseq start with 200;

select playerIdseq.nextVal from dual;

