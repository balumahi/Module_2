package com.capgemini.core.ems;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.service.EmployeeServiceImpl;
import java.util.List;

public class TestEmployeeService
{
	public static void main(String[] args)
	{
		EmployeeServiceImpl employeeService = new EmployeeServiceImpl();
		
		// Testing
		
		/*Employee employee = new Employee();
		
		employee.setName("Eric Men");
		employee.setDepartment("IT");
		employee.setDesignation("Security");
		employee.setSalary(13000);
		employeeService.addEmployee(employee);
		*/
		// End testing addEmployee method
			
	/*	Employee emp = employeeService.getEmployee(1001);
		
		System.out.println(emp);*/
		
		//End of getEmployee method
		
		// Test update Employee method
		
/*		
Employee employee = new Employee();

		
		employee.setName("Eric");
		employee.setDepartment("IT");
		employee.setDesignation("Software");
		employee.setSalary(17000);
		//employeeService.addEmployee(employee);
		employeeService.updateEmployee(employee);*/
		
		
		// test get employee method
		
		//==================================
		Employee emp = employeeService.removeEmployee(1002);
		
		System.out.println("Employee removed");
		System.out.println(emp);
		
		///============================================
		List<Employee> emps = employeeService.getEmployee();
		
		for(Employee employee : emps)
		{
			System.out.println(employee);
		}
		// End of Test getEmployees method
		
		
		
		
	}
}
