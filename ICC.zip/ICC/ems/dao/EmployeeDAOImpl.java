package com.capgemini.core.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.exceptions.EmployeeException;
import com.capgemini.core.ems.util.DBUtil;

public class EmployeeDAOImpl implements IEmployeeDAO {


	
	@Override
	public int addEmployee(Employee e) throws EmployeeException {
		// TODO Auto-generated method stub
		
		
		
		int generatedId = -1;
		try(Connection con = DBUtil.getConnection())
		{

			
			Statement stm = con.createStatement();
			
			ResultSet res = stm.executeQuery("select empIdseq.nextVal from dual");
			
			if (res.next() == false)
				throw new EmployeeException("something went wrong while generating employee id");
			
			int id =  res.getInt(1);
			String name = e.getName();
			float salary = e.getSalary();
			String dept = e.getDepartment();
			String desg = e.getDesignation();
			
			PreparedStatement pstm = con.prepareStatement("Insert into employee values (?,?,?,?,?)");
			pstm.setInt(1,id);
			pstm.setString(2,name);
			pstm.setString(3, dept);
			pstm.setString(4,desg);
			pstm.setFloat(5,salary);
			
			pstm.execute();
			generatedId=id;
		}
		catch (SQLException e1)
		{
			e1.printStackTrace();
			throw new EmployeeException(e1.getMessage());
		}
		catch (Exception e1)
		{
			e1.printStackTrace();
			throw new EmployeeException(e1.getMessage());
		}
		return generatedId;
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		
		Employee employee = null;
		try(Connection con = DBUtil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("Select * from Employee where id=?");
			pstm.setInt(1, id);
			
			ResultSet res = pstm.executeQuery();
			if (res.next() == false)
				throw new EmployeeException("The Employee found with id "+ id);
			
			employee = new Employee();
			
			employee.setId(res.getInt("id"));
			employee.setName(res.getString("name"));
			employee.setDepartment(res.getString("department"));
			employee.setDesignation(res.getString("designation"));
			employee.setSalary(res.getFloat("salary"));
		}
		catch(SQLException e)
		{
		e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		return  employee;
	}

	@Override
	public void updateEmployee(Employee employee) throws EmployeeException {

	
		try(Connection con = DBUtil.getConnection())
		{
			int id      = employee.getId();
			String name  = employee.getName();
			float salary = employee.getSalary();
			String dept = employee.getDepartment();
			String desg = employee.getDesignation();
			
			PreparedStatement pstm = con.prepareStatement("update Employee set name=?, department=?, designation=?, salary=? where id=?");
			
			pstm.setString(1,name);
			pstm.setString(2, dept);
			pstm.setString(3,desg);
			pstm.setFloat(4,salary);
			pstm.setInt(5,id);
			
			pstm.execute();
			
		}
		catch(SQLException e)
		{
		e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		
		
	}

	@Override
	public Employee removeEmployee(int id) throws EmployeeException {
		
		Employee employee = null;
		try(Connection con = DBUtil.getConnection())
		{
			employee = getEmployee(id);
			
			if ( employee == null)
			{
				throw new EmployeeException("No Employee found with id"+ id);
			}
			PreparedStatement pstm = con.prepareStatement("delete from Employee where id=?");
			
			pstm.setInt(1,id);
			pstm.execute();
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
			
		
		
		return employee;
	}

	@Override
	public List<Employee> getEmployee() throws EmployeeException {


		List<Employee> employees = new ArrayList<Employee>();
		try(Connection con = DBUtil.getConnection())
		{
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select * from employee");
			
			while (res.next())
			{
				
				Employee employee = new Employee();
				
				employee.setId(res.getInt("id"));
				employee.setName(res.getString("name"));
				employee.setDepartment(res.getString("department"));
				employee.setDesignation(res.getString("designation"));
				employee.setSalary(res.getFloat("salary"));
				
				employees.add(employee);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		
		
		return employees;
	}

}
