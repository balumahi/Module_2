package com.capgemini.core.ems.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.exceptions.EmployeeException;
import com.capgemini.core.ems.service.EmployeeServiceImpl;
import com.capgemini.core.ems.service.IEmployeeService;

public class EmployeeView
{
	// Loose Coupling
	private IEmployeeService employeeService;
	public EmployeeView()
	{
		employeeService = new EmployeeServiceImpl();
	}
	
	
	public static void main(String[] args)
	{
		EmployeeView emsUI = new EmployeeView();
		
		while(true)
		{
		emsUI.showMenu();
		}
	}
	public void showMenu()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("1) Add Employee");
		System.out.println("2) Get Employee");
		System.out.println("3) Update Employee");
		System.out.println("4) Remove Employee");
		System.out.println("5) View All Employee");
		System.out.println("6) Exit Application");
		
		System.out.println("Insert your choics");;
		int choice = scanner.nextInt();
		
		switch (choice)
		{
		case 1: addEmployee(); 
		break;
		case 2: getEmployee(); 
		break;
		case 3: updateEmployee();
		break;
		case 4: removeEmployee();
		break;
		case 5: viewEmployee();
		break;
		case 6: 
		
				System.out.println("Thank you ! Existing Application");;
				System.exit(0);
		break;
		
		default :
				System.out.println("Invalid Input");
		break;
				
		}
		
		
		
	}


	private void addEmployee() 
	{
		Scanner scanner= new Scanner(System.in);
		System.out.println("Provide employee information");
		System.out.println("Employee name");
		String name = scanner.next();
		
		System.out.println("Employee Department");
		String dept = scanner.next();
		
		System.out.println("Employee Designation");
		String desg = scanner.next();
		
		System.out.println("Employee salary");
		Float salary = scanner.nextFloat();
		
		//Validate of input (skipping for now)
		
		
		Employee employee = new Employee();
		employee.setName(name);
		employee.setDepartment(dept);
		employee.setDesignation(desg);
		employee.setSalary(salary);
		
		//send emp obj to database via service
		
		try
		{
			int id = employeeService.addEmployee(employee);
			System.out.println("Employee added succesufully with id "+ id);
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}
	private void getEmployee() 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("\nEmployee id");
		int id= scanner.nextInt();
	
		try
		{
			Employee employee = employeeService.getEmployee(id);
			
			System.out.println("\n**Employee Information**");
			System.out.println("EmployeeID: "+ employee.getId());
			System.out.println("Employee Name: "+ employee.getName());
			System.out.println("Employee Department: "+ employee.getDepartment());
			System.out.println("Employee Designation: "+ employee.getDesignation());
			System.out.println("Employee Salary: "+ employee.getSalary());
			


		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}
	private void updateEmployee() 
	{
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Updating employee information");
		
		System.out.println("\nEmployee id");
		int id= scanner.nextInt();
		
		try
		{
			// Attempting to get employee assuming is passed is valid
			
			Employee employee =  employeeService.getEmployee(id);
			
			// Since employee obj is retrived, upddate is and send to 
			
			System.out.println("Name :"+ employee.getName());
			System.out.println("Do you want to update Name (y/n)?");
			
			char reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating employee name
			{
				System.out.println("Enter new name: ");
				String name = scanner.next();
				employee.setName(name);
			}
			
			System.out.println("Department :"+ employee.getDepartment());
			System.out.println("Do you want to update Department (y/n)?");
			
			 reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating employee name
			{
				System.out.println("Enter new Department: ");
				String Department = scanner.next();
				employee.setDepartment(Department);
			}
			
			System.out.println("Designation :"+ employee.getDesignation());
			System.out.println("Do you want to update Designation(y/n)?");
			
			 reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating employee name
			{
				System.out.println("Enter new Designation: ");
				String Designation = scanner.next();
				employee.setDesignation(Designation);
			}
			
			System.out.println("Salary:"+ employee.getSalary());
			System.out.println("Do you want to update Salary(y/n)?");
			
			 reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating employee name
			{
				System.out.println("Enter new Salary: ");
				Float salary = scanner.nextFloat();
				employee.setSalary(salary);
			}
			// Updating employee record
			
			employeeService.updateEmployee(employee);
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
		private void removeEmployee()
		{
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("Remove eemployee information");
			System.out.println("\nEmployee id");
			int id= scanner.nextInt();

			try
			{
				Employee employee = employeeService.getEmployee(id);
				
				employeeService.removeEmployee(id);
				System.out.println("Employee details removed");
				System.out.println("EmployeeID: "+ employee.getId());
				System.out.println("Employee Name: "+ employee.getName());
				System.out.println("Employee Department: "+ employee.getDepartment());
				System.out.println("Employee Designation: "+ employee.getDesignation());
				System.out.println("Employee Salary: "+ employee.getSalary());
				
			}
			catch(EmployeeException e)
			{
				e.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		private void viewEmployee()
		{
			try
			{
				List<Employee> employeeList = employeeService.getEmployee();
				Iterator<Employee> it = employeeList.iterator();
				while (it.hasNext())
				{
					Employee employee= it.next();
					System.out.println(employee.getId() + "\t"+ employee.getName() + "\t"+ employee.getDepartment() + "\t" + employee.getDesignation() + "\t" + employee.getSalary());
					
					
					
					
				}
			}
			catch(EmployeeException e)
			{
				e.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	
	}
	


