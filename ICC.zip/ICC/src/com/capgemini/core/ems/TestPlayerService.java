package com.capgemini.core.ems;

import com.capgemini.core.ems.bean.Players;
import com.capgemini.core.ems.service.IPlayerServiceImpl;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class TestPlayerService
{
	public static void main(String[] args)
	{
		IPlayerServiceImpl playerServiceImpl = new IPlayerServiceImpl();
		
	
		/*
		player.setName("Dhoni");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date dt = sdf.parse(d);
		java.sql.Date date = new Date(dt.getTime());
		player.setDob(date);
		
	*/
		
Players player = new Players();

player.setId(145);		
player.setName("MahendraS");
player.setDob(null);
player.setCountry("India");
player.setStyle("Righ");
player.setCenturies(15);
player.setMatches(240);
player.setRuns(10000);
		
playerServiceImpl.updatePlayers(player);

//employeeService.addEmployee(employee);
		
		
		// test get employee method
		
		//==================================
	Players players = playerServiceImpl.removePlayers(160);
		
		System.out.println("Player removed");
		System.out.println(player);
		
		/*///============================================
		List<Players> player = playerService.getPlayers();
		
		for(Players player : player)
		{
			System.out.println(player);
		}
		// End of Test getEmployees method
		*/
		
		
		
	}
}
