package com.capgemini.core.ems.bean;

import java.sql.Date;

public class Players 
{
	
	private int id;
	private String name;
	private Date  dob;
	private String country;

	private String style;
	private int centuries;
	private int matches;
	private int runs;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	
	
	
	
	public void setCenturies(int centuries) {
		this.centuries = centuries;
	}
	public int getMatches() {
		return matches;
	}
	public void setMatches(int matches) {
		this.matches = matches;
	}
	public int getRuns() {
		return runs;
	}
	public void setRuns(int runs) {
		this.runs = runs;
	}
	
	
	public Players(int id, String name, Date dob, String country, String style,
			int centuries, int matches, int runs) {
		super();
		this.id = id;
		this.name = name;
		this.dob = dob;
		this.country = country;
		this.style = style;
		this.centuries = centuries;
		this.matches = matches;
		this.runs = runs;
	}
	
	
	public Players() {
		super();
	}
	
	@Override
	public String toString() {
		return "Players [id=" + id + ", name=" + name + ", dob=" + dob
				+ ", country=" + country + ", style=" + style + ", centures="
				+ centuries + ", matches=" + matches + ", runs=" + runs + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Players other = (Players) obj;
		if (id != other.id)
			return false;
		return true;
	}
	public static void add(Players player) {
		// TODO Auto-generated method stub
		
	}
	public int getCenturies() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
}
