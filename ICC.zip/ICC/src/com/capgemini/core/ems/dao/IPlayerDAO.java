package com.capgemini.core.ems.dao;

import java.util.List;

import com.capgemini.core.ems.bean.Players;
import com.capgemini.core.ems.exceptions.PlayerException;

public interface IPlayerDAO 
{

public int addPlayers(Players p) throws PlayerException;
	
	public Players getPlayer(int id) throws PlayerException;
	
	public void updatePlayers(Players Player) throws PlayerException;
	
	public Players removePlayers(int id) throws PlayerException;
	
	public List<Players> getPlayers() throws PlayerException;

	
	
	
}
