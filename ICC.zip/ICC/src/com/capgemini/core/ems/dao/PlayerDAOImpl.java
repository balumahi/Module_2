package com.capgemini.core.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;



import oracle.net.aso.p;

import com.capgemini.core.ems.bean.Players;
import com.capgemini.core.ems.exceptions.PlayerException;
import com.capgemini.core.ems.util.DBUtil;
import com.capgemini.core.ems.view.PlayerView;

public class PlayerDAOImpl implements IPlayerDAO
{

	private int Playerid;





	@Override
	public int addPlayers(Players p) throws PlayerException
	{
	
		int generatedId = -1;
		try(Connection con = DBUtil.getConnection())
		{
			
			Statement stm = con.createStatement();
			
			ResultSet res = stm.executeQuery("select playerIdseq.nextVal from dual");
			
			if (res.next() == false)
				throw new PlayerException("something went wrong while generating player id");
			
			int id =  res.getInt(1);
			String name = p.getName();
			String country = p.getCountry();
			Date dob = p.getDob();
			String sty = p.getStyle();
			int cen= p.getCenturies();
			int match = p.getMatches();
			int runs = p.getRuns();
			
			
			PreparedStatement pstm = con.prepareStatement("Insert into players values (?,?,?,?,?,?,?,?)");
			pstm.setInt(1,id);
			pstm.setString(2,name);
			pstm.setString(3, country);
			pstm.setDate(4, dob);
			pstm.setString(5, sty);
			pstm.setInt(6,cen);
			pstm.setInt(7,match);
			pstm.setInt(8,runs);
			
			pstm.execute();
			generatedId=id;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return generatedId;
	}

	@Override
	public Players getPlayer(int id) throws PlayerException {
		Players players = null;
		
		try(Connection con = DBUtil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("select * from players where playerid=?");
			pstm.setInt(1, id);
			
			ResultSet res = pstm.executeQuery();
			if (res.next() == false)
				throw new PlayerException("The Player found with id "+ id);
			
			
			players = new Players();
			
			players.setId(1);
			players.setName(res.getString(2));
			players.setCountry(res.getString(3));
			players.setDob(res.getDate(4));
			players.setStyle(res.getString(5));
			players.setCenturies(res.getInt(6));
			players.setMatches(res.getInt(7));
			players.setRuns(res.getInt(8));
		
			

		}
		catch(SQLException e)
		{
		e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}
		
		return players;
	}

	@Override
	public void updatePlayers(Players Player) throws PlayerException {
		
		try(Connection con = DBUtil.getConnection())
		{
			int id = Player.getId();
			String name = Player.getName();
			String country = Player.getCountry();
			Date dob = Player.getDob();
			String sty = Player.getStyle();
			int cen= Player.getCenturies();
			int match = Player.getMatches();
			int runs = Player.getRuns();
			
		
		PreparedStatement pstm = con.prepareStatement("update Players set name=?, Country=?, Dob=?, Battingstyle=? ,Noofcentures=?, Noofmatchesplayed =?, Totalruns=? where Playerid=?");
		
		pstm.setString(1,name);
		pstm.setString(2,country);
		pstm.setDate(3, dob);
		pstm.setString(4,sty);
		pstm.setInt(5,cen);
		pstm.setInt(6,match);
		pstm.setInt(7,runs);
		pstm.setInt(8,id);
		
		pstm.execute();
		
		
		
	} catch (SQLException e) {
		
		e.printStackTrace();
		throw new PlayerException(e.getMessage());
	}
	catch (Exception e)
	{
		e.printStackTrace();
		throw new PlayerException(e.getMessage());
	}
		
	}

	@Override
	public Players removePlayers(int id) throws PlayerException {
	
		
		Players player = null;
		try(Connection con = DBUtil.getConnection())
		{
			
			player = getPlayer(id);
			
			if( player == null)
			{
				throw new PlayerException("No Player found with id"+ id);
			}
			
			PreparedStatement pstm = con.prepareStatement("Remove from player where id=?");
			pstm.setInt(1,id);
			pstm.execute();
			
		}
		catch(SQLException e)
		{
		e.printStackTrace();
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}
		
		return player;
	}



	

@Override
	public List<Players> getPlayers() throws PlayerException {
	
		List<Players> players = new ArrayList<Players>();
		try(Connection con = DBUtil.getConnection())
		{
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select * from players");
			
			while (res.next())
			{
				
				Players player = new Players ();
				
				player.setId(res.getInt(1));
				player.setName(res.getString(2));
				player.setCountry(res.getString(3));
				player.setDob(res.getDate(4));
				player.setStyle(res.getString(5));
				player.setCenturies(res.getInt(6));
				player.setMatches(res.getInt(7));
				player.setRuns(res.getInt(8));
				
				players.add(player);
			}
		}
			
			catch(SQLException e)
			{
			e.printStackTrace();
			
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				throw new PlayerException(e.getMessage());
			}
		
	
		return players;
		}

}
	

	