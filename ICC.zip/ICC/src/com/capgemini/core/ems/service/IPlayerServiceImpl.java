package com.capgemini.core.ems.service;

import java.util.List;

import com.capgemini.core.ems.bean.Players;

import com.capgemini.core.ems.dao.IPlayerDAO;
import com.capgemini.core.ems.dao.PlayerDAOImpl;
import com.capgemini.core.ems.exceptions.PlayerException;

public class IPlayerServiceImpl implements IPlayerService {

	
private IPlayerDAO playerDAO;
	
	public IPlayerServiceImpl()
	{
		playerDAO= new PlayerDAOImpl();
	}
	public int addPlayers(Players p) throws PlayerException {
		// TODO Auto-generated method stub
		return playerDAO.addPlayers(p);
	}

	@Override
	public Players getPlayer(int id) throws PlayerException {
		// TODO Auto-generated method stub
		return playerDAO.getPlayer(id);
	}

	@Override
	public void updatePlayers(Players Player) throws PlayerException {
		// TODO Auto-generated method stub
					playerDAO.updatePlayers(Player);
	}

	@Override
	public Players removePlayers(int id) throws PlayerException {
		// TODO Auto-generated method stub
		return playerDAO.removePlayers(id);
	}

	@Override
	public List<Players> getPlayers() throws PlayerException {
		// TODO Auto-generated method stub
		return  playerDAO.getPlayers();
	}

}
