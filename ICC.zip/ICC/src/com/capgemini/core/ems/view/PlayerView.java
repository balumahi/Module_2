package com.capgemini.core.ems.view;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.ems.bean.Players;
import com.capgemini.core.ems.exceptions.PlayerException;
import com.capgemini.core.ems.service.IPlayerServiceImpl;
import com.capgemini.core.ems.service.IPlayerService;

public class PlayerView
{
	// Loose Coupling
	private IPlayerService playerService;
	public PlayerView()
	{
		playerService = new IPlayerServiceImpl();
	}
	
	
	public static void main(String[] args)
	{
		PlayerView emsUI = new PlayerView();
		
		while(true)
		{
		emsUI.showMenu();
		}
	}
	public void showMenu()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("1) Add Player");
		System.out.println("2) Get Player");
		System.out.println("3) Update Player");
		System.out.println("4) Remove Player");
		System.out.println("5) View All Player");
		System.out.println("6) Exit Application");
		
		System.out.println("Insert your choics");;
		int choice = scanner.nextInt();
		
		switch (choice)
		{
		case 1: addPlayer(); 
		break;
		case 2: getPlayer();  
		break;
		case 3: updatePlayer(); 
		break;
		case 4: removeplayer(); 
		break;
		case 5: viewPlayer(); 
		break;
		case 6: 
		
				System.out.println("Thank you ! Existing Application");;
				System.exit(0);
		break;
		
		default :
				System.out.println("Invalid Input");
		break;
				
		}
		
		
		
	}



/*
	private void removePlayer() {
		// TODO Auto-generated method stub
		
	}
*/

	



	private void addPlayer() 
	{
		Scanner scanner= new Scanner(System.in);
		System.out.println("Provide player information");
		System.out.println("player Name");
		String name = scanner.next();
		
		System.out.println("Player Country");
		String country = scanner.next();
		
		System.out.println("Player Dob");
		String date = scanner.next();
		
		System.out.println("Player Style");
		String style = scanner.next();
		
		System.out.println("Player Centuries");
		int centuries = scanner.nextInt();
		

		System.out.println("Player Matches");
		int matches= scanner.nextInt();
		

		System.out.println("Player Runs");
		int runs = scanner.nextInt();
		
		//Validate of input (skipping for now)
		
		
		Players Player = new Players();
		
		Player.setName(name);
		
		Date dob = Date.valueOf(date);
		
		/*SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date dt;
		java.sql.Date dob = null;
		try {
			dt = sdf.parse(date);
			dob= new Date(dt.getTime());
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		*/
	
		
		Player.setDob(dob);
		Player.setCountry(country);
		Player.setStyle(style);
		Player.setCenturies(centuries);
		Player.setMatches(matches);
		Player.setRuns(runs);
		
		//send emp obj to database via service
		
		try
		{
			int id = playerService.addPlayers(Player);
			System.out.println("Player added succesufully with id "+ id);
		}
		catch(PlayerException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}
	private void getPlayer() 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("\nPlayer id");
		int id= scanner.nextInt();
	
		try
		{
			Players player = playerService.getPlayer(id);
			
			System.out.println("\n**Player Information**");
			System.out.println("player ID: "+ player.getId());
			System.out.println("player Name: "+ player.getName());
			System.out.println("player Counrty: "+ player.getCountry());
			System.out.println("player Dob: "+ player.getDob());
			System.out.println("player Style: "+ player.getStyle());
			System.out.println("player Centuries: "+ player.getCenturies());
			System.out.println("player Matches: "+ player.getMatches());
			System.out.println("player Runs: "+ player.getRuns());
			

		}
		catch(PlayerException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
		
		
	}
	private void updatePlayer() 
	{
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Updating player information");
		
		System.out.println("\nPlayer id");
		int id= scanner.nextInt();
		
		try
		{
			// Attempting to get employee assuming is passed is valid
			
			Players player =  playerService.getPlayer(id);
			
			// Since employee obj is retrived, upddate is and send to 
			
			System.out.println("Name :"+ player.getName());
			System.out.println("Do you want to update Name (y/n)?");
			
			char reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating employee name
			{
				System.out.println("Enter new name: ");
				String name = scanner.next();
				player.setName(name);
			}
			
			System.out.println("Country :"+ player.getCountry());
			System.out.println("Do you want to update Country (y/n)?");
			
			 reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating player name
			{
				System.out.println("Enter new country: ");
				String Country = scanner.next();
				player.setCountry(Country);
			}
			
			System.out.println("Dob :"+ player.getDob());
			System.out.println("Do you want to update Dob (y/n)?");
			
			 reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating employee name
			{
				System.out.println("Enter new Dob: ");
			
				
				String dob = scanner.next();
				Date date=Date.valueOf(dob);
				/*//java.sql.Date dob = null;
				//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
				//java.util.Date dt;
				try {
					dt = sdf.parse(date);
					dob= new Date(dt.getTime());
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			*/
				player.setDob(date);
			}
			
			System.out.println("Style :"+ PlayerView.getStyle());
			System.out.println("Do you want to update Style(y/n)?");
			
			 reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating employee name
			{
				System.out.println("Enter new Style: ");
				String Style = scanner.next();
				player.setStyle(Style);
			}
			
			System.out.println("Centuries:"+ player.getCenturies());
			System.out.println("Do you want to update Centuries(y/n)?");
			
			 reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating employee name
			{
				System.out.println("Enter new Centuries: ");
				int  centuries = scanner.nextInt();
				player.setCenturies(centuries);
			}
			
			System.out.println("Matches:"+ player.getMatches());
			System.out.println("Do you want to update Matches(y/n)?");
			
			 reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating employee name
			{
				System.out.println("Enter new Matches: ");
				int Matches = scanner.nextInt();
				player.setMatches(Matches);
			}
			
			System.out.println("Runs:"+ player.getRuns());
			System.out.println("Do you want to update Runs(y/n)?");
			
			 reply = scanner.next().toLowerCase().charAt( 0 );
			
			if(reply == 'y') // Updating employee name
			{
				System.out.println("Enter new Runs: ");
				int Runs = scanner.nextInt();
				player.setRuns(Runs);
			}
			// Updating employee record
			
			playerService.updatePlayers(player);
		}
		catch(PlayerException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
		private static String getStyle() {
		// TODO Auto-generated method stub
		return null;
	
		}


		private void removeplayer()
		{
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("Remove Player information");
			System.out.println("\nPlayer id");
			int id= scanner.nextInt();

			try
			{
				Players player = playerService.getPlayer(id);
				
				playerService.removePlayers(id);
				System.out.println("player details removed");
				System.out.println("playerID: "+ player.getId());
				System.out.println("player Name: "+ player.getName());
				System.out.println("player Country: "+ player.getCountry());
				System.out.println("Eplayer Dob: "+ player.getDob());
				System.out.println("player Style: "+ player.getStyle());
				System.out.println("player Centuries: "+ player.getCenturies());
				System.out.println("player Matches: "+ player.getMatches());
				System.out.println("player Runs: "+ player.getRuns());
				
				
			}
			catch(PlayerException e)
			{
				e.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		private void viewPlayer()
		{
			try
			{
				List<Players> playerList = playerService.getPlayers();
				Iterator<Players> it = playerList.iterator();
				while (it.hasNext())
				{
					Players player= it.next();
					System.out.println(player.getId() + "\t"+ player.getName() + "\t"+ player.getCountry() +"\t"+ player.getDob() + "\t" + player.getStyle() + "\t" + player.getCenturies() + "\t" +player.getMatches() + "\n" + player.getRuns());
					
					
					
				}
			}
			catch(PlayerException e)
			{
				e.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	
	}
	


