 
 
CREATE TABLE BookingDetails(bookingId NUMBER PRIMARY KEY,custId VARCHAR2(10),busId REFERENCES BusDetails(busId),noOfSeats Number);


select * from BookingDetails;
 


CREATE TABLE BusDetails(busId NUMBER PRIMARY KEY, busType VARCHAR(20), fromStop VARCHAR(20),
toStop VARCHAR(20),fare DECIMAL, availableSeats NUMBER, dateOfJourney DATE);



 select * from BusDetails;
 
 